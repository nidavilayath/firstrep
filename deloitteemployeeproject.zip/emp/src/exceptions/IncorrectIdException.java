package exceptions;

public class IncorrectIdException extends RuntimeException {

    public IncorrectIdException(String msg) {
        super(msg);
    }
}
